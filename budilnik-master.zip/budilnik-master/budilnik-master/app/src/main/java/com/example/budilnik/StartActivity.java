package com.example.budilnik;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;

//public class StartActivity extends MainActivity {


   public class StartActivity1 extends AppCompatActivity {

      @Override
      protected void onCreate(Bundle savedInstanceState) {
         super.onCreate(savedInstanceState);
         Intent intent = new Intent(this, MyService.class);
           StartService(intent);
//        setContentView(R.layout.activity_main);
      }
   }











    //public void onCreate(Bundle savedInstanceState) {
        //...
//Тут должен запускаться сервис с проигрыванием музыки
   //-------------------------------------------------------------------------------
  // Intent intent = new Intent(this, MyService.class);
    //  StartActivity (intent);
        //-------------------------------------------------------------------------------
    //}
    //а это нужно для того чтобы при выключении приложения музыка выключалась
   //private void onBackPressed() {
    //   stopService(new Intent(this, MyService.class));
   //}

 //   /** Обработка нажатия кнопок */
 //   public void onClick(View v) {
 //...
   }
 }